@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在启动指尖花园，请稍候……
echo 浏览器将自动打开。请保持此窗口开启。
"%~dp0runtime\node.exe" "%~dp0serve.cjs"
echo.
echo 服务已停止。按任意键关闭窗口。
pause >nul
